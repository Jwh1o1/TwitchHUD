HOST = "irc.chat.twitch.tv"
PORT = 6667
PASS = "oauth:cw184llgqaqxniqg3xnga4p90q0pac"
IDENT = "jwh1o1"
CHANNEL = "jwh1o1"